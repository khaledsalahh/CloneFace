# Smooth arrow animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/vlt_dev/pen/NWMNzpE](https://codepen.io/vlt_dev/pen/NWMNzpE).

